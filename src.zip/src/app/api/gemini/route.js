import { NextResponse } from "next/server";

export async function POST(req) {
  try {
    const { prompt, text } = await req.json();

    // TEMP MOCK RESPONSE
    const result = `
${prompt}

${text}
`;

    return NextResponse.json({
      result,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error: "Something went wrong",
      },
      {
        status: 500,
      },
    );
  }
}

import { useAIStore } from '@/store/aiStore';
import { Plus, Check, X, Brain, Sparkles, Sparkle, ShieldAlert, Loader2, Send, BookOpen, Lightbulb } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { askGemini } from '@/lib/ai/gemini';
import { useSettingsStore } from '@/store/settingsStore';
import { generateAIResponse } from '@/lib/ai';

export default function AISidebar() {
  const selectedText = useAIStore((state) => state.selectedText);
  const setAIResponse = useAIStore((state) => state.setAIResponse);
  const { provider } = useSettingsStore();
  const [prompt, setPrompt] = useState('');
  const pendingSuggestion = useAIStore((state) => state.pendingSuggestion);
  const clearConversation = useAIStore((state) => state.clearConversation);
  const setPendingSuggestion = useAIStore(
    (state) => state.setPendingSuggestion
  );
  const setLoading = useAIStore((state) => state.setLoading);
  const loading = useAIStore((state) => state.loading);
  const clearPendingSuggestion = useAIStore(
    (state) => state.clearPendingSuggestion
  );
  const documentText = useAIStore((state) => state.documentText);
  const { messages, addMessage } = useAIStore();
  const messagesEndRef = useRef(null);
  const { geminiApiKey, groqApiKey } = useSettingsStore();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({
      behavior: 'smooth',
    });
  }, [messages, loading, pendingSuggestion]);

  async function handleRewrite() {
    if (!prompt.trim()) return;

    try {
      setLoading(true);

      const apiKey = useSettingsStore.getState().geminiApiKey;
      const updatedMessages = [
        ...messages,
        {
          role: 'user',
          content: prompt,
        },
      ];

      addMessage({
        role: 'user',
        content: prompt,
      });

      const history = updatedMessages
        .map((msg) => `${msg.role}: ${msg.content}`)
        .join('\n');

      const response = await generateAIResponse({
        provider,
        prompt,
        selectedText,
        documentText,
        history,
      });
      const messageMatch = response.match(/MESSAGE:\s*([\s\S]*?)SUGGESTION:/i);

      const suggestionMatch = response.match(/SUGGESTION:\s*([\s\S]*)/i);

      const message = messageMatch?.[1]?.trim() || response;

      const suggestion = suggestionMatch?.[1]?.trim() || '';
      addMessage({
        role: 'assistant',
        content: message,
      });

      if (suggestion && suggestion !== message) {
        setPendingSuggestion(suggestion);
      }

      setPrompt('');
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      className="w-[380px] max-h-[90vh] h-[-webkit-fill-available] flex flex-col overflow-hidden"
      style={{ borderRadius: '0 .5rem .5rem 0' }}
    >
      {/* Header */}
      <div className="p-1 flex justify-end items-center justify-between">
        <span className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <span className="relative flex h-1 w-1">
              <span
                className={`absolute inline-flex h-full w-full animate-ping rounded-full ${geminiApiKey === '' && groqApiKey === '' ? 'bg-red-400' : 'bg-green-400'} opacity-75`}
              />

              <span
                className={`relative inline-flex h-1 w-1 rounded-full ${geminiApiKey === '' && groqApiKey === '' ? 'bg-red-500' : 'bg-green-500'}`}
              />
            </span>

            <p className="text-[8px] uppercase text-[--text-muted]">
              {provider}
            </p>
          </span>
          <button
            onClick={() => {
              clearConversation();
              clearPendingSuggestion();
              setPrompt('');
            }}
            className="flex items-center gap-1 py-1 px-1 rounded-md hover:bg-[var(--conqr-secondary)] hover:text-[var(--hover)] text-[11px] bg-[var(--foreground)] cursor-pointer hover:shadow-xl shadow-black/5 hover:translate-y-[-1px] transition-[800ms]"
          >
            <Plus size={10} />
            New Chat
          </button>
        </span>
      </div>
      {/* Messages */}
      <div className="flex-1 min-h-0 overflow-y-auto p-4">
        <div className="space-y-4">
          {/* Selected Text */}
          {selectedText && (
              <div>
                <div className="mb-2 !text-[8px] uppercase text-[--text-secondary]">
                  Selected Text
                </div>

                <div
                    className="border-l-2 border-l-[#bbb] bg-[#ddd] p-1 text-[11px] whitespace-pre-wrap"
                    style={{ maxHeight: '140px', overflow: 'auto' }}
                >
                  {selectedText || 'No text selected'}
                </div>
              </div>
          )}
          {/* Conversation */}
          {messages.length > 0 && (
            <div>
              <div className="space-y-3">
                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`rounded-xl border w-[70%] w-fit min-w-[40%] whitespace-pre-wrap ${
                      message.role === 'user'
                        ? 'ml-auto bg-gradient-to-br from-[var(--conqr-secondary)] to-[var(--conqr-secondary-light)] text-[var(--white)]'
                        : 'bg-[#e0e0e0] text-[var(--conqr-secondary)] border-1 border-[#d7d7d7] p-0 max-w-[80%] !text-[#777] shadow-xl shadow-black/5'
                    }`}
                    style={{
                      padding: '.5rem',
                      marginBottom: '.25rem',
                    }}
                  >
                    {message.role !== 'user' && (
                        <p
                            className="px-1 flex gap-[.15rem] items-center rounded-md uppercase !text-[8px]"
                            style={{
                              fontWeight: 900,
                              backgroundColor:
                                  message.role === 'user' ? '#ffffff44' : '#00000012',
                              width: 'fit-content',
                              margin: 0,
                              marginBottom: '.5rem',
                            }}
                        >
                          {message.role !== 'user' && <Sparkle size={6} />}
                          {message.role}
                        </p>
                    )}
                    <p
                      className="text-[11px]"
                      style={{ margin: 0, lineHeight: '110%' }}
                    >
                      {message.content?.replace(/MESSAGE:/gi, '')?.trim()}
                    </p>
                  </div>
                ))}
              </div>
              {loading && (
                <div className="mb-2 flex items-center gap-1 text-[8px] uppercase text-[--text-muted] font-mono">
                  <span>AI is thinking</span>

                  <div className="flex">
                    <span className="animate-bounce [animation-delay:0ms]">
                      .
                    </span>

                    <span className="animate-bounce [animation-delay:150ms]">
                      .
                    </span>

                    <span className="animate-bounce [animation-delay:300ms]">
                      .
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}
          {/* AI Suggestion */}
          {pendingSuggestion && (pendingSuggestion !== '---' || pendingSuggestion !== 'None' || pendingSuggestion !== 'None needed.') && (
            <div>
              <div
                className="bg-[#792CA214] border-1 border-[#792CA220] p-2 rounded-xl text-[11px] !text-[#792CA2] whitespace-pre-wrap"
                style={{ maxHeight: '140px', overflow: 'auto', lineHeight: '110%' }}
              >
                <div  className="flex gap-[.15rem] items-center uppercase !text-[8px] text-[#792CA2] mb-4"
                      style={{
                        fontWeight: 900,
                        width: 'fit-content',
                      }}>
                  <Lightbulb size={8} />
                  Suggestion
                </div>
                {pendingSuggestion}
              </div>

              <div className="content-center" style={{ marginTop: '6px' }}>
                <button
                  onClick={() => {
                    setAIResponse(pendingSuggestion);
                    clearPendingSuggestion();
                  }}
                  className="flex-1 rounded-lg bg-[var(--conqr-secondary)] w-fit px-2 py-1 text-xs text-white"
                  style={{ width: 'fit-content' }}
                >
                  <Check size={10} />
                </button>

                <button
                  onClick={clearPendingSuggestion}
                  className="flex-1 rounded-lg border border-[var(--border)] px-2 py-1 text-xs !bg-red-500 text-white"
                  style={{ backgroundColor: 'red', width: 'fit-content' }}
                >
                  <X size={10} />
                </button>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>
      {/* Input */}
      <div className="rounded-[28px] border border-[#ebe7df] bg-[#f8f6f3] ml-2 shadow-[0_8px_30px_rgba(0,0,0,0.04)]">
        <div className="relative overflow-hidden rounded-[24px] px-4 py-4 shadow-inner flex items-end">
          {/* Input */}
          <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleRewrite();
                }
              }}
              rows={4}
              placeholder="Initiate a query or send a command to the AI..."
              className="w-full resize-none bg-transparent pr-4 text-[11px] text-[#1d1d1d] placeholder:text-[#9b9b9b] outline-none"
          />
            <button
                onClick={handleRewrite}
                className="flex p-2 items-center justify-center rounded-xl bg-gradient-to-br from-[var(--conqr-secondary)] to-[var(--conqr-secondary-light)] text-white shadow-[0_8px_20px_rgba(123,97,255,0.35)] transition-all hover:scale-105 active:scale-95"
            >
              {loading ? (
                  <Loader2 size={14} className="animate-spin" />
              ) : (
                  <Send size={14} />
              )}
            </button>
          </div>
      </div>
    </div>
  );
}

"use client";

const sizes = [
  12,
  14,
  16,
  18,
  24,
  32,
  48,
];

export default function FontSizeDropdown({
  onSelect,
}) {
  return (
    <div className="absolute top-12 left-0 z-50 w-24 rounded-2xl border border-[var(--border)] bg-[var(--foreground)] p-2 shadow-2xl">
      {sizes.map((size) => (
        <button
          key={size}
          onClick={() =>
            onSelect(size)
          }
          className="flex w-full items-center rounded-lg px-3 py-2 text-left text-sm transition-all hover:bg-[var(--hover)]"
        >
          {size}px
        </button>
      ))}
    </div>
  );
}
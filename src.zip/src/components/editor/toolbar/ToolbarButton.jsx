import { cn } from "@/lib/utils";

export default function ToolbarButton({children, active, onClick,}) {
    return (
        <button onClick={onClick} className={cn("flex h-8 w-8 items-center justify-center rounded-sm cursor-pointer", "hover:bg-[var(--foreground)]", active && "bg-gray-200")}>
            {children}
        </button>
    );
}
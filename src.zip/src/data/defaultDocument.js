const defaultDocument = `
# NDA Review Report

## Executive Summary

This agreement contains several clauses that may expose the receiving party to unnecessary legal and operational risk.

### Key Risks Identified

- Broad indemnification obligations
- Unlimited liability exposure
- Missing termination safeguards
- Ambiguous confidentiality duration

## Suggested Revision

The liability clause should be capped to direct damages only and exclude consequential damages.

## AI Analysis

The confidentiality clause appears commercially reasonable; however, the survival period of 10 years may be excessive depending on jurisdiction.

## Recommendation

Proceed after revising Sections 4, 7, and 11.
`;

export default defaultDocument;